import { v } from "convex/values";
import { mutation, query } from "./_generated/server";

/**
 * Update a user's subscription tier and status
 */
export const updateSubscription = mutation({
    args: {
        userId: v.string(),
        tier: v.string(),
        status: v.string(),
        polarCustomerId: v.optional(v.string()),
        isFoundingMember: v.optional(v.boolean()),
        foundingWave: v.optional(v.number()),
    },
    handler: async (ctx, args) => {
        const profile = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q) => q.eq("userId", args.userId))
            .unique();

        if (profile) {
            await ctx.db.patch(profile._id, {
                subscription_tier: args.tier as "free" | "basic" | "pro" | "business" | "enterprise",
                subscription_status: args.status,
                polar_customer_id: args.polarCustomerId,
                is_founding_member: args.isFoundingMember ?? profile.is_founding_member,
                founding_wave: args.foundingWave ?? profile.founding_wave,
                updated_at: new Date().toISOString(),
            });
            return true;
        }
        return false;
    },
});

/**
 * Update subscription by Polar Customer ID
 */
export const updateSubscriptionByCustomerId = mutation({
    args: {
        polarCustomerId: v.string(),
        tier: v.string(),
        status: v.string(),
    },
    handler: async (ctx, args) => {
        const profile = await ctx.db
            .query("profiles")
            .withIndex("by_polar_customer", (q) => q.eq("polar_customer_id", args.polarCustomerId))
            .unique();

        if (profile) {
            await ctx.db.patch(profile._id, {
                subscription_tier: args.tier as "free" | "basic" | "pro" | "business" | "enterprise",
                subscription_status: args.status,
                updated_at: new Date().toISOString(),
            });
            return true;
        }
        return false;
    },
});

/**
 * Update subscription by Dodo IDs
 */
export const updateSubscriptionByDodoId = mutation({
    args: {
        dodoCustomerId: v.optional(v.string()),
        dodoPaymentId: v.optional(v.string()),
        tier: v.string(),
        status: v.string(),
    },
    handler: async (ctx, args) => {
        let profile = null;

        if (args.dodoCustomerId) {
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_dodo_customer", (q) => q.eq("dodo_customer_id", args.dodoCustomerId))
                .unique();
        }

        if (!profile && args.dodoPaymentId) {
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_dodo_payment", (q) => q.eq("dodo_payment_id", args.dodoPaymentId))
                .unique();
        }

        if (profile) {
            await ctx.db.patch(profile._id, {
                subscription_tier: args.tier as "free" | "basic" | "pro" | "business" | "enterprise",
                subscription_status: args.status,
                dodo_customer_id: args.dodoCustomerId ?? profile.dodo_customer_id,
                dodo_payment_id: args.dodoPaymentId ?? profile.dodo_payment_id,
                updated_at: new Date().toISOString(),
            });
            return true;
        }
        return false;
    },
});

/**
 * Ensure a profile exists for a user
 */
export const ensureProfile = mutation({
    args: {
        userId: v.string(),
        email: v.string(),
        subscriptionTier: v.optional(v.string()),
    },
    handler: async (ctx, args) => {
        const email = args.email.toLowerCase();
        const existing = await ctx.db
            .query("profiles")
            .withIndex("by_email", (q) => q.eq("email", email))
            .unique();

        if (existing) {
            if (!existing.userId) {
                await ctx.db.patch(existing._id, { userId: args.userId });
            }
            return existing._id;
        }

        return await ctx.db.insert("profiles", {
            userId: args.userId,
            email,
            subscription_tier: (args.subscriptionTier as "free" | "basic" | "pro" | "business" | "enterprise") || "free",
            optimizations_remaining: 3,
            optimizations_used: 0,
            comprehensive_credits_remaining: 0,
            is_admin: false,
            is_founding_member: false,
            created_at: Date.now(),
        });
    },
});

/**
 * Get profile by userId or email (for server-side API calls)
 * This is a public query that doesn't require authentication
 */
export const getProfileByUserId = query({
    args: {
        userId: v.string(),
        email: v.optional(v.string()),
    },
    handler: async (ctx, args) => {
        // First try by userId
        let profile = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q) => q.eq("userId", args.userId))
            .unique();

        // If not found and email provided, try by email
        if (!profile && args.email) {
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_email", (q) => q.eq("email", args.email!.toLowerCase()))
                .unique();
        }

        return profile;
    },
});

/**
 * Get user usage statistics
 */
export const getUsage = query({
    args: {},
    handler: async (ctx) => {
        const identity = await ctx.auth.getUserIdentity();
        if (!identity) return null;

        // First try to find by userId
        let profile = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q) => q.eq("userId", identity.subject))
            .unique();

        // If not found by userId, try by email (handles OAuth login scenarios)
        if (!profile && identity.email) {
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_email", (q) => q.eq("email", identity.email!.toLowerCase()))
                .unique();

            // Note: Can't update userId in a query, but ensureProfile mutation handles this
        }

        if (!profile) return null;

        // Determine if admin (unlimited access)
        const isAdmin = profile.is_admin ?? false;

        // Calculate tier-based limits (enterprise = business tier)
        const tier = profile.subscription_tier;
        const tierLimit = isAdmin ? Infinity :
            tier === 'pro' ? 400 :
                tier === 'business' || tier === 'enterprise' ? 1000 :
                    tier === 'basic' ? 150 : 12; // Adjusted free limit to 10 + buffer

        // Map Convex profile to UserData structure used in the app
        return {
            tier: profile.subscription_tier,
            optimizationsUsed: profile.optimizations_used,
            optimizationsLimit: tierLimit,
            premiumCreditsUsed: 0,
            premiumCreditsLimit: 0,
            canOptimize: profile.optimizations_remaining > 0 || (tier !== "free"),
            canOrchestrate: tier !== "free" && tier !== "basic",
            hasMcpAccess: tier === "business" || tier === "enterprise" || isAdmin,
            comprehensiveCreditsRemaining: profile.comprehensive_credits_remaining,
            subscriptionStatus: profile.subscription_status,
            isAdmin: isAdmin,
            displayName: profile.display_name || profile.full_name,
            userId: profile.userId, // Return the actual profile user ID
            email: profile.email,
        };

    },
});
/**
 * Get all user profiles (Admin only)
 */
export const getAllProfiles = query({
    args: {},
    handler: async (ctx) => {
        return await ctx.db.query("profiles").collect();
    },
});

/**
 * Get profile by email
 */
export const getProfileByEmail = query({
    args: { email: v.string() },
    handler: async (ctx, args) => {
        const email = args.email.toLowerCase();
        return await ctx.db
            .query("profiles")
            .withIndex("by_email", (q) => q.eq("email", email))
            .unique();
    },
});

/**
 * Update user admin status
 */
export const updateAdminStatus = mutation({
    args: { userId: v.string(), isAdmin: v.boolean() },
    handler: async (ctx, args) => {
        const user = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q) => q.eq("userId", args.userId))
            .unique();

        if (!user) throw new Error("User not found");

        await ctx.db.patch(user._id, {
            is_admin: args.isAdmin,
            updated_at: new Date().toISOString(),
        });
    },
});
/**
 * Update subscription status only
 */
export const updateSubscriptionStatus = mutation({
    args: {
        userId: v.optional(v.string()),
        polarCustomerId: v.optional(v.string()),
        status: v.string(),
    },
    handler: async (ctx, args) => {
        let profile = null;

        if (args.userId) {
            const userId = args.userId;
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_user", (q) => q.eq("userId", userId))
                .unique();
        } else if (args.polarCustomerId) {
            const customerId = args.polarCustomerId;
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_polar_customer", (q) => q.eq("polar_customer_id", customerId))
                .unique();
        }

        if (profile) {
            await ctx.db.patch(profile._id, {
                subscription_status: args.status as "active" | "canceled" | "past_due" | "trialing" | "unpaid" | "incomplete" | "paused",
                updated_at: new Date().toISOString(),
            });
            return true;
        }
        return false;
    },
});

/**
 * Get credits for a user by userId or email (for agent API)
 */
export const getCreditsForAgent = query({
    args: {
        userId: v.string(),
        email: v.optional(v.string()),
    },
    handler: async (ctx, args) => {
        // Try by userId first
        let profile = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q) => q.eq("userId", args.userId))
            .unique();

        // If not found and email provided, try by email
        if (!profile && args.email) {
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_email", (q) => q.eq("email", args.email!.toLowerCase()))
                .unique();
        }

        if (!profile) return null;

        return {
            comprehensive_credits_remaining: profile.comprehensive_credits_remaining,
            optimizations_remaining: profile.optimizations_remaining,
            subscription_tier: profile.subscription_tier,
            userId: profile.userId,  // Return actual userId for subsequent calls
        };
    },
});

/**
 * Deduct comprehensive credits (for agent API)
 */
export const deductCreditsForAgent = mutation({
    args: {
        userId: v.string(),
        email: v.optional(v.string()),
        amount: v.number(),
    },
    handler: async (ctx, args) => {
        // Find profile by userId first
        let profile = await ctx.db
            .query("profiles")
            .withIndex("by_user", (q) => q.eq("userId", args.userId))
            .unique();

        // If not found and email provided, try by email
        if (!profile && args.email) {
            profile = await ctx.db
                .query("profiles")
                .withIndex("by_email", (q) => q.eq("email", args.email!.toLowerCase()))
                .unique();
        }

        if (!profile) {
            return { success: false, error: "User not found" };
        }

        const currentCredits = profile.comprehensive_credits_remaining;
        if (currentCredits < args.amount) {
            return {
                success: false,
                error: "Insufficient credits",
                credits_remaining: currentCredits,
            };
        }

        // Deduct credits
        await ctx.db.patch(profile._id, {
            comprehensive_credits_remaining: currentCredits - args.amount,
            updated_at: new Date().toISOString(),
        });

        return {
            success: true,
            credits_remaining: currentCredits - args.amount,
        };
    },
});

